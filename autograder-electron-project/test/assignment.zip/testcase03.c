int main(){

    printf("This is testcase03.c program");

    return 0;
}