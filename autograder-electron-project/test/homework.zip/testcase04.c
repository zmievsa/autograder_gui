int main(){

    printf("This is testcase04.c program. Added this to distinguish between assignment file.");

    return 0;
}