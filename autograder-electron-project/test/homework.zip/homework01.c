int main(){
    unsigned long long r1,r2,r3,r4;

    r1 = fibonnacci(0);
    r2 = fibonnacci(2);

    int score = 0;

    return 0;
}